public class Test {
    public static void main(String[] args) {
        System.out.println("My name is John Tran");
        System.out.println("I am 31 years old");
        System.out.println("My hometown is Honolulu, Hawaii");
    }
    
    
}