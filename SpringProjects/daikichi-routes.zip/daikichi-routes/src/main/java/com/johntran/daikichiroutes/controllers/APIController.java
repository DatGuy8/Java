package com.johntran.daikichiroutes.controllers;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/daikichi")
public class APIController {
	
	@RequestMapping("")
	public String daikichiIndex() {
		return "Welcome!";
	}
	
	@RequestMapping("/today")
	public String daiToday() {
		return "Today you will find luck in all your endeavors!";
	}

	@RequestMapping("/tomorrow")
	public String daiTomorrow() {
		return "Tomorrow, an opportunity will aarise, so be sure to be open to new ideas!";
	}
}
