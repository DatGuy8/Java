package com.johntran.zookeeper;

public class MammalTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Gorilla gorilla1 = new Gorilla("Steve");
		Bat bat1 = new Bat("Dracula");
		
		gorilla1.throwPoop().throwPoop().throwPoop().eatBananas().eatBananas().climbSomething();	
		gorilla1.dislpayEnergy();
		
		
		bat1.attackTown().attackTown().attackTown();
		bat1.eatHuman().eatHuman();
		bat1.fly().fly();
		bat1.dislpayEnergy();
		
		Bat bat2 = new Bat();
		bat2.dislpayEnergy();
	}

}
