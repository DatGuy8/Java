package com.johntran.zookeeper;

public class MammalTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Gorilla gorilla1 = new Gorilla("Steve");
		
		
		gorilla1.throwPoop().throwPoop().throwPoop().eatBananas().eatBananas().climbSomething();	
		gorilla1.dislpayEnergy();
		
		
		
		
//		gorilla1.displayEnergy();
	}

}
